/* Host mocks: test live PS2 path and Memory Card selection logic without
 * touching either a Windows save directory or a PS2 memory card. */
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <3ds.h>

#include "romfs_paths.h"

static int asset_source, host_has_save, card_has_save[2];
static int card_formatted[2], last_mc_port;
static int mc_init_calls, created_count;
static char created[64][128], opened[512];

int SifLoadModule(const char *name, int argc, const char *args)
{ (void)name; (void)argc; (void)args; return 1; }

int mcInit(int type)
{ (void)type; ++mc_init_calls; return 0; }

int mcGetInfo(int port, int slot, int *type, int *free_clusters, int *formatted)
{
    assert(slot == 0 && port >= 0 && port <= 1);
    last_mc_port = port;
    *type = card_formatted[port] ? 2 : 0;
    *free_clusters = 9000;
    *formatted = card_formatted[port] ? 1 : 0;
    return 0;
}

int mcSync(int mode, int *cmd, int *result)
{
    assert(mode == 0);
    (void)cmd;
    *result = card_formatted[last_mc_port] ? -1 : -10;
    return 1;
}

static int contains_created(const char *path)
{
    for (int i=0; i<created_count; ++i)
        if (!strcmp(created[i], path)) return 1;
    return 0;
}

void PS2_BootPathProbe(const char *path, int error, int success)
{ (void)path; (void)error; (void)success; }

FILE *__real_fopen(const char *path, const char *mode)
{
    snprintf(opened, sizeof(opened), "%s", path);
    if (!strcmp(mode, "rb")) {
        if (asset_source == 0 && !strcmp(path, "host:romfs/menus/main_menu.txt")) return tmpfile();
        if (asset_source == 1 && !strcmp(path, "mass:/GDPS2/romfs/menus/main_menu.txt")) return tmpfile();
        if (asset_source == 2 && !strcmp(path, "cdrom0:/ROMFS/MENUS/MAIN_MENU.TXT;1")) return tmpfile();
        if (host_has_save && !strcmp(path, "host:save/config.json")) return tmpfile();
        if (card_has_save[0] && !strcmp(path, "mc0:GDPS2/save/config.json")) return tmpfile();
        if (card_has_save[1] && !strcmp(path, "mc1:GDPS2/save/config.json")) return tmpfile();
        errno = ENOENT;
        return NULL;
    }
    if (strchr(mode, 'w')) return tmpfile();
    errno = EINVAL;
    return NULL;
}

int __real_stat(const char *path, struct stat *st)
{
    if (contains_created(path)) {
        memset(st, 0, sizeof(*st));
#ifdef _S_IFDIR
        st->st_mode = _S_IFDIR;
#else
        st->st_mode = S_IFDIR;
#endif
        return 0;
    }
    errno = ENOENT;
    return -1;
}

int __real_mkdir(const char *path, mode_t mode)
{
    (void)mode;
    if (created_count >= 64) abort();
    snprintf(created[created_count++], sizeof(created[0]), "%s", path);
    return 0;
}

int __real_open(const char *path, int flags, ...)
{ (void)path; (void)flags; return -1; }
DIR *__real_opendir(const char *path)
{ (void)path; return NULL; }
int __real_access(const char *path, int mode)
{ (void)path; (void)mode; return -1; }
int __real_remove(const char *path)
{ (void)path; return -1; }
int __real_unlink(const char *path)
{ (void)path; return -1; }
int __real_rename(const char *from, const char *to)
{ (void)from; (void)to; return -1; }

FILE *__wrap_fopen(const char *path, const char *mode);

static void reset_case(int asset, int host_save, int mc0, int mc1,
                       int mc0_save, int mc1_save)
{
    asset_source = asset;
    host_has_save = host_save;
    card_formatted[0] = mc0;
    card_formatted[1] = mc1;
    card_has_save[0] = mc0_save;
    card_has_save[1] = mc1_save;
    last_mc_port = 0;
    mc_init_calls = created_count = 0;
    opened[0] = 0;
    assert(romfsInit() == 0);
    PS2_SaveInit();
}

static void check_destination(const char *expected)
{
    FILE *f = __wrap_fopen("/3ds/gd3ds/config.json", "w");
    assert(f != NULL);
    assert(!strcmp(opened, expected));
    fclose(f);
}

int main(void)
{
    reset_case(0, 1, 1, 1, 0, 1);
    check_destination("host:save/config.json");
    assert(mc_init_calls == 0); /* do not migrate an existing host save */

    reset_case(0, 0, 1, 1, 0, 1);
    check_destination("mc1:GDPS2/save/config.json");
    assert(contains_created("mc1:GDPS2"));
    assert(contains_created("mc1:GDPS2/save"));

    reset_case(0, 0, 1, 0, 0, 0);
    check_destination("mc0:GDPS2/save/config.json");

    reset_case(0, 0, 0, 0, 0, 0);
    check_destination("host:save/config.json");

    reset_case(1, 0, 0, 0, 0, 0);
    check_destination("mass:/GDPS2/save/config.json");

    reset_case(2, 0, 0, 1, 0, 0);
    check_destination("mc1:GDPS2/save/config.json");

    puts("PASS: six save-device scenarios, existing host preserved, existing MC preferred, fallback host/mass");
    return 0;
}
