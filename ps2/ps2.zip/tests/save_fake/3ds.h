#pragma once
typedef int Result;
Result romfsInit(void);
