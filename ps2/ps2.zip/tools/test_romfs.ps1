param([string]$HostCC = 'gcc')

$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$out = Join-Path $root 'ps2/out/tests'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$exe = Join-Path $out 'romfs_paths_smoke.exe'
$args_cc = @('-std=c11', '-Wall', '-Wextra', '-Werror',
    "-I$(Join-Path $root 'ps2/src')",
    (Join-Path $root 'ps2/tests/romfs_paths_smoke.c'),
    (Join-Path $root 'ps2/src/romfs_paths.c'), '-o', $exe)
& $HostCC @args_cc
if ($LASTEXITCODE -ne 0) { throw "Host ROMFS test build failed: $LASTEXITCODE" }
& $exe
if ($LASTEXITCODE -ne 0) { throw "Host ROMFS test failed: $LASTEXITCODE" }
