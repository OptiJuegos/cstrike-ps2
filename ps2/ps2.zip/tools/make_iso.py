#!/usr/bin/env python3
"""Build a bootable PS2 ISO (for OPL, PCSX2 or a burned disc) from the release.

Layout: SYSTEM.CNF, the ELF under its disc id (e.g. SLUS_666.01) and romfs/
with ISO9660 names from disc_names.py (the game reads them with disc_names.c).

Usage:
  python ps2/tools/make_iso.py
  python ps2/tools/make_iso.py --elf ps2/out/release/GeometryDashPS2.elf --id SLUS_666.01
"""
import argparse
import re
import sys
from pathlib import Path

import pycdlib

sys.path.insert(0, str(Path(__file__).parent))
import disc_names  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
RELEASE = ROOT / "ps2" / "out" / "release"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--elf", type=Path, default=RELEASE / "GeometryDashPS2.elf")
    ap.add_argument("--romfs", type=Path, default=RELEASE / "romfs")
    ap.add_argument("--id", default="SLUS_666.01", help="disc id, form SLUS_123.45")
    ap.add_argument("--out", type=Path, default=RELEASE / "GeometryDashPS2.iso")
    ap.add_argument("--vmode", default="NTSC", choices=["NTSC", "PAL"])
    opts = ap.parse_args()

    if not re.fullmatch(r"[A-Z]{4}_\d{3}\.\d{2}", opts.id):
        sys.exit(f"--id must look like SLUS_123.45, got {opts.id}")
    for need in (opts.elf, opts.romfs / "menus" / "main_menu.txt"):
        if not need.exists():
            sys.exit(f"missing {need} (run build.bat first)")

    iso = pycdlib.PyCdlib()
    iso.new(interchange_level=2, vol_ident="GEOMETRYDASHPS2")

    def add_file(src: Path, iso_name: str):
        iso.add_file(str(src), "/" + iso_name + ";1")

    cnf = (f"BOOT2 = cdrom0:\\{opts.id};1\r\nVER = 1.00\r\nVMODE = {opts.vmode}\r\n").encode("ascii")
    import io
    iso.add_fp(io.BytesIO(cnf), len(cnf), "/SYSTEM.CNF;1")
    add_file(opts.elf, opts.id)

    made = set()
    count = size = 0
    for path in sorted(opts.romfs.rglob("*")):
        rel = "romfs/" + path.relative_to(opts.romfs).as_posix()
        mangled = disc_names.path(rel)
        if path.is_dir():
            continue
        parts = mangled.split("/")
        for i in range(1, len(parts)):
            d = "/" + "/".join(parts[:i])
            if d not in made:
                iso.add_directory(d)
                made.add(d)
        add_file(path, mangled)
        count += 1
        size += path.stat().st_size
    opts.out.parent.mkdir(parents=True, exist_ok=True)
    iso.write(str(opts.out))
    iso.close()
    print(f"ISO: {opts.out} ({opts.out.stat().st_size / 1048576:.1f} MiB), "
          f"{count} romfs files ({size / 1048576:.1f} MiB), id {opts.id}")


if __name__ == "__main__":
    main()
