/* File/path compatibility layer for the offline Geometry Dash PS2 port.
 * The game uses romfs:/ and /3ds/gd3ds/ paths from its original 3DS code.
 * Assets are READ-ONLY and saves use a separate folder on a writable device.
 * Device drivers must already be present: no fake USB or ISO mount is made.
 */
#include <3ds.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <libmc.h>

#include "romfs_paths.h"
#include "disc_names.h"
#include "boot_trace.h"

static const char *asset_roots[] = {
    /* PCSX2 maps host: to the ELF directory. build_engine.ps1 leaves the
     * packaged ROMFS one level below ps2/out/, under package/romfs/. */
    "host:", "host:package", "mass:/GDPS2", "cdrom0:"
};
#define DISC_ROOT_INDEX 3
/* Save destinations may be different from the asset device. The special
 * mc0:GDPS2 format follows PS2SDK's mc0:APP/file POSIX convention. */
static const char *save_root = "host:";
static int asset_root_index;

FILE *__real_fopen(const char *, const char *);
int __real_open(const char *, int, ...);
int __real_stat(const char *, struct stat *);
DIR *__real_opendir(const char *);
int __real_access(const char *, int);
int __real_mkdir(const char *, mode_t);
int __real_remove(const char *);
int __real_unlink(const char *);
int __real_rename(const char *, const char *);

/* Disc assets: cdrom0: only answers exact ISO9660 names (uppercase, usually
 * ";1"), and the accepted separator differs between loaders. Try each spelling
 * once, then remember the one that worked. */
static int disc_style = -1;

static int on_disc(void) { return asset_root_index == DISC_ROOT_INDEX; }

/* "romfs:/a/b" -> "romfs/a/b". Returns 0 if path is not an asset path. */
static int disc_rel(const char *path, char rel[512])
{
    if (strncmp(path, "romfs:/", 7)) return 0;
    return snprintf(rel, 512, "romfs/%s", path + 7) < 512;
}

typedef int (*DiscTry)(const char *mapped, void *ctx);

/* Runs try() on every spelling until it returns nonzero; that value is returned. */
static int disc_each(const char *path, DiscTry try, void *ctx)
{
    char rel[512], mapped[512];
    if (!disc_rel(path, rel)) return 0;
    int first = disc_style >= 0 ? disc_style : 0;
    for (int k = 0; k < PS2_DISC_STYLES; ++k) {
        int style = (first + k) % PS2_DISC_STYLES;
        if (PS2_DiscPath(rel, style, mapped, sizeof(mapped)) < 0) return 0;
        int r = try(mapped, ctx);
        if (r) {
            if (disc_style != style) {
                printf("GDPS2 ROMFS: disc spelling style=%d (%s)\n", style, mapped);
                disc_style = style;
            }
            return r;
        }
    }
    return 0;
}

struct DiscFopen { const char *mode; FILE *file; };
static int try_fopen(const char *mapped, void *ctx)
{
    struct DiscFopen *c = ctx;
    c->file = __real_fopen(mapped, c->mode);
    return c->file != NULL;
}

struct DiscOpen { int flags, mode, fd; };
static int try_open(const char *mapped, void *ctx)
{
    struct DiscOpen *c = ctx;
    c->fd = __real_open(mapped, c->flags, c->mode);
    return c->fd >= 0;
}

/* The cdrom0: IOP driver can fail stat() for files that open fine. */
struct DiscStat { struct stat *st; };
static int try_stat(const char *mapped, void *ctx)
{
    struct DiscStat *c = ctx;
    if (__real_stat(mapped, c->st) == 0) return 1;
    FILE *f = __real_fopen(mapped, "rb");
    if (!f) return 0;
    long size = -1;
    if (fseek(f, 0, SEEK_END) == 0) size = ftell(f);
    fclose(f);
    memset(c->st, 0, sizeof(*c->st));
    c->st->st_mode = S_IFREG | 0444;
    c->st->st_size = size < 0 ? 0 : size;
    return 1;
}

static int try_exists(const char *mapped, void *ctx)
{
    (void)ctx;
    FILE *f = __real_fopen(mapped, "rb");
    if (!f) return 0;
    fclose(f);
    return 1;
}

/* Called from main() with argv[0] so a disc launch probes the disc first. */
static int launched_from_disc;
void PS2_SetLaunchPath(const char *argv0)
{
    launched_from_disc = argv0 && (!strncmp(argv0, "cdrom", 5) || !strncmp(argv0, "cdfs", 4));
    printf("GDPS2 ROMFS: launch path=%s disc=%d\n", argv0 ? argv0 : "(null)", launched_from_disc);
}

static const char *select_base(Ps2PathKind kind)
{
    return kind == PS2_PATH_ASSET ? asset_roots[asset_root_index] :
           save_root;
}

static Ps2PathKind resolve(const char *path, char out[512])
{
    /* An empty base is not allowed, even for passthrough paths. */
    Ps2PathKind kind = PS2_PathMap(path, "host:", out, 512);
    if (kind == PS2_PATH_INVALID || kind == PS2_PATH_NATIVE) return kind;
    return PS2_PathMap(path, select_base(kind), out, 512);
}

Result romfsInit(void)
{
    char path[512];
    asset_root_index = 0;
    disc_style = -1;
    save_root = "host:";
    /* Probe an actual required asset, not just an I/O device prefix. */
    int found = 0;
    const unsigned count = sizeof(asset_roots)/sizeof(asset_roots[0]);
    unsigned order[8];
    unsigned n = 0;
    if (launched_from_disc) order[n++] = DISC_ROOT_INDEX;
    for (unsigned i=0; i<count; i++)
        if (!(launched_from_disc && i == DISC_ROOT_INDEX)) order[n++] = i;
    for (unsigned k=0; k<n; k++) {
        unsigned i = order[k];
        if (i == DISC_ROOT_INDEX) {
            asset_root_index = (int)i;
            struct DiscFopen c = { "rb", NULL };
            printf("GDPS2 ROMFS: probing cdrom0: romfs/menus/main_menu.txt\n");
            if (disc_each("romfs:/menus/main_menu.txt", try_fopen, &c)) {
                PS2_BootPathProbe("cdrom0:romfs/menus/main_menu.txt", 0, 1);
                fclose(c.file);
                found = 1;
                break;
            }
            printf("GDPS2 ROMFS: probe failed path=cdrom0: errno=%d\n", errno);
            PS2_BootPathProbe("cdrom0:romfs/menus/main_menu.txt", errno, 0);
            asset_root_index = 0;
            continue;
        }
        if (PS2_PathMap("romfs:/menus/main_menu.txt", asset_roots[i],
                        path, sizeof(path)) != PS2_PATH_ASSET) {
            printf("GDPS2 ROMFS: invalid probe path for %s\n", asset_roots[i]);
            continue;
        }
        printf("GDPS2 ROMFS: probing %s\n", path);
        FILE *f = __real_fopen(path, "rb");
        if (f) {
            PS2_BootPathProbe(path, 0, 1);
            fclose(f);
            asset_root_index = (int)i;
            found = 1;
            break;
        }
        printf("GDPS2 ROMFS: probe failed path=%s errno=%d\n", path, errno);
        PS2_BootPathProbe(path, errno, 0);
    }
    /* The final save root is selected by PS2_SaveInit(), after SIO2/pad init. */
    if (asset_root_index == 2) save_root = "mass:/GDPS2";
    printf("PS2 ROMFS: assets=%s, initial saves=%s (%s)\n",
        asset_roots[asset_root_index], save_root,
        found ? "asset probe OK" : "no game assets found");
    return found ? 0 : -1;
}

Result romfsExit(void) { return 0; }

static int save_present(const char *base)
{
    char path[512];
    if (PS2_PathMap("/3ds/gd3ds/config.json", base, path, sizeof(path))
        != PS2_PATH_SAVE) return 0;
    FILE *file = __real_fopen(path, "rb");
    if (!file) return 0;
    fclose(file);
    return 1;
}

static int ensure_real_folder(const char *folder)
{
    struct stat st;
    if (__real_stat(folder, &st) == 0) return S_ISDIR(st.st_mode);
    if (__real_mkdir(folder, 0777) == 0) return 1;
    /* Some IOP devices do not implement stat fully but report EEXIST for
     * already-created directories. Never delete/recreate a saved folder. */
    if (errno == EEXIST) return 1;
    return __real_stat(folder, &st) == 0 && S_ISDIR(st.st_mode);
}

static int memory_card_ready(int port)
{
    int type = MC_TYPE_NONE, free_clusters = 0, formatted = 0, status = -999;
    if (mcGetInfo(port, 0, &type, &free_clusters, &formatted) < 0 ||
        mcSync(MC_WAIT, NULL, &status) < 0) return 0;
    /* MCMAN may return formatted=0 even for a formatted card. Its sync
     * result distinguishes -1 (new formatted) from -2 (unformatted). */
    printf("GDPS2 SAVE: mc%d: type=%d free=%d formatted=%d result=%d\n",
           port, type, free_clusters, formatted, status);
    return type == MC_TYPE_PS2 && (status == 0 || status == -1);
}

static int use_memory_card(const char *base)
{
    char folder[64];
    if (snprintf(folder, sizeof(folder), "%s", base) >= (int)sizeof(folder) ||
        !ensure_real_folder(folder)) return 0;
    if (snprintf(folder, sizeof(folder), "%s/save", base) >= (int)sizeof(folder) ||
        !ensure_real_folder(folder)) return 0;
    save_root = base;
    printf("GDPS2 SAVE: using Memory Card %s/save/\n", save_root);
    return 1;
}

void PS2_SaveInit(void)
{
    const int asset_from_host = asset_root_index <= 1;
    static const char *cards[] = { "mc0:GDPS2", "mc1:GDPS2" };
    int ready[2] = {0, 0};

    /* Never silently abandon already-existing PCSX2/ps2link saves. */
    if (asset_from_host && save_present("host:")) {
        save_root = "host:";
        puts("GDPS2 SAVE: existing host:save/config.json, preserving host saves");
        return;
    }

    /* Pad initialization has already loaded SIO2MAN. These are the classic
     * ROM modules used by the bundled PS2SDK libmc sample. No formatting. */
    int man = SifLoadModule("rom0:MCMAN", 0, NULL);
    int serv = SifLoadModule("rom0:MCSERV", 0, NULL);
    int init = mcInit(MC_TYPE_MC);
    printf("GDPS2 SAVE: MCMAN=%d MCSERV=%d mcInit=%d\n", man, serv, init);
    if (init >= 0) {
        for (int i = 0; i < 2; ++i) ready[i] = memory_card_ready(i);
        /* Prefer an existing card save over initializing a new location. */
        for (int i = 0; i < 2; ++i)
            if (ready[i] && save_present(cards[i]) && use_memory_card(cards[i]))
                return;
        for (int i = 0; i < 2; ++i)
            if (ready[i] && use_memory_card(cards[i])) return;
    }

    /* Existing USB/host mapping remains the fallback when there is no
     * formatted and writable card; never redirect saves to read-only CD. */
    if (asset_from_host) save_root = "host:";
    else if (asset_root_index == 2) save_root = "mass:/GDPS2";
    else save_root = "host:";
    printf("GDPS2 SAVE: no usable Memory Card; fallback %s%ssave/\n",
           save_root, save_root[strlen(save_root)-1] == ':' ? "" : "/");
}

static int can_modify(Ps2PathKind kind)
{
    if (kind == PS2_PATH_ASSET) { errno = EROFS; return 0; }
    if (kind == PS2_PATH_INVALID) { errno = EINVAL; return 0; }
    return 1;
}

/* Helper for saving settings; 3DS allows mkdir of nested SD paths. */
static void ensure_parent_dirs(const char *path)
{
    char folder[512];
    size_t n = strlen(path);
    if (n >= sizeof(folder)) return;
    memcpy(folder, path, n+1);
    char *colon = strchr(folder, ':');
    char *begin = colon ? colon + 1 : folder;
    while (*begin == '/') ++begin;
    for (char *p = begin; *p; ++p) {
        if (*p != '/') continue;
        *p = 0;
        __real_mkdir(folder, 0777);
        *p = '/';
    }
}

static int is_disc_asset(const char *path)
{
    return on_disc() && path && !strncmp(path, "romfs:/", 7);
}

FILE *__wrap_fopen(const char *path, const char *mode)
{
    char mapped[512];
    if (is_disc_asset(path)) {
        if (!mode || strpbrk(mode, "wa+")) { errno = EROFS; return NULL; }
        struct DiscFopen c = { mode, NULL };
        if (disc_each(path, try_fopen, &c)) return c.file;
        printf("GDPS2 ROMFS: disc open failed original=%s errno=%d\n", path, errno);
        return NULL;
    }
    Ps2PathKind kind = resolve(path, mapped);
    if (kind == PS2_PATH_INVALID || !mode) { errno = EINVAL; return NULL; }
    if (kind == PS2_PATH_ASSET && strpbrk(mode, "wa+")) {
        errno = EROFS; return NULL;
    }
    if (kind == PS2_PATH_SAVE && strpbrk(mode, "wa+")) ensure_parent_dirs(mapped);
    FILE *result = __real_fopen(mapped, mode);
    if (!result && kind == PS2_PATH_ASSET)
        printf("GDPS2 ROMFS: open failed original=%s mapped=%s errno=%d\n",
               path, mapped, errno);
    return result;
}

int __wrap_open(const char *path, int flags, int mode)
{
    char mapped[512];
    if (is_disc_asset(path)) {
        if (flags & (O_WRONLY | O_RDWR | O_CREAT | O_TRUNC)) { errno = EROFS; return -1; }
        struct DiscOpen c = { flags, mode, -1 };
        return disc_each(path, try_open, &c) ? c.fd : -1;
    }
    Ps2PathKind kind = resolve(path, mapped);
    if (kind == PS2_PATH_INVALID) { errno = EINVAL; return -1; }
    if (kind == PS2_PATH_ASSET && (flags & (O_WRONLY | O_RDWR | O_CREAT | O_TRUNC))) {
        errno = EROFS;
        return -1;
    }
    if (kind == PS2_PATH_SAVE && (flags & O_CREAT)) ensure_parent_dirs(mapped);
    return __real_open(mapped, flags, mode);
}

int __wrap_stat(const char *path, struct stat *st)
{
    char mapped[512];
    if (is_disc_asset(path)) {
        struct DiscStat c = { st };
        if (disc_each(path, try_stat, &c)) return 0;
        errno = ENOENT;
        return -1;
    }
    if (resolve(path, mapped) == PS2_PATH_INVALID) { errno=EINVAL; return -1; }
    return __real_stat(mapped, st);
}

DIR *__wrap_opendir(const char *path)
{
    char mapped[512];
    /* readdir() on cdrom0: returns no entries; never pretend it works. */
    if (is_disc_asset(path)) { errno = ENOTSUP; return NULL; }
    if (resolve(path, mapped) == PS2_PATH_INVALID) { errno=EINVAL; return NULL; }
    return __real_opendir(mapped);
}

int __wrap_access(const char *path, int mode)
{
    char mapped[512];
    if (is_disc_asset(path)) {
        if (mode & W_OK) { errno = EROFS; return -1; }
        if (disc_each(path, try_exists, NULL)) return 0;
        errno = ENOENT;
        return -1;
    }
    Ps2PathKind kind = resolve(path, mapped);
    if (kind == PS2_PATH_INVALID) { errno=EINVAL; return -1; }
    if (kind == PS2_PATH_ASSET && (mode & W_OK)) { errno=EROFS; return -1; }
    return __real_access(mapped, mode);
}

int __wrap_remove(const char *path)
{
    char mapped[512];
    if (!can_modify(resolve(path, mapped))) return -1;
    return __real_remove(mapped);
}
int __wrap_unlink(const char *path)
{
    char mapped[512];
    if (!can_modify(resolve(path, mapped))) return -1;
    return __real_unlink(mapped);
}
int __wrap_rename(const char *from, const char *to)
{
    char a[512], b[512];
    if (!can_modify(resolve(from, a)) || !can_modify(resolve(to, b))) return -1;
    return __real_rename(a, b);
}
int __wrap_mkdir(const char *path, mode_t mode)
{
    char mapped[512];
    Ps2PathKind kind = resolve(path, mapped);
    if (!can_modify(kind)) return -1;
    if (kind == PS2_PATH_SAVE) ensure_parent_dirs(mapped);
    return __real_mkdir(mapped, mode);
}
